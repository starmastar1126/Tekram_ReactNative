export default {
  dashboard : {
    availabilityText : "Availability",
    activeText : "AVAILABLE",
    inActiveText : "BUSY",
    title : 'DASHBOARD',
    newOrder : "Create New Order",
    accountStatement : "Account Statement",
    inputName : "Client Name",
    inputPrice : "Price"
  },
  accountStatment:{
    title : "ACCOUNT STATEMENT",
    order_number : "Order number : ",
    order_amount : "Order amount : ",
    client_name : "Client name : ",
    total_amount : "Total amount : "
  },

}