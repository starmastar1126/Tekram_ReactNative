export default Images = {
    user : require('../../assets/user.jpg')
}